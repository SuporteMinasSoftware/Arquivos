UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (201, 'Rejei��o: N�mero m�ximo de numera��o a inutilizar ultrapassou o limite', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-201-n%C3%BAmero-m%C3%A1ximo-de-numera%C3%A7%C3%A3o-a-inutilizar-ultrapassou-o-limite-como-resolver-98.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (202, 'Rejei��o: Falha no reconhecimento da autoria ou integridade do arquivo digital', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (203, 'Rejei��o: Emissor n�o habilitado para emiss�o de NF-e', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-203-emitente-n%C3%A3o-habilitado-para-emiss%C3%A3o-de-nf-e-como-resolver-99.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (204, 'Duplicidade de NF-e', 'Existe uma nota j� autorizada com esta n�mera��o, procure o suporte', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-204-duplicidade-de-nf-e-nrec999999999999999-como-resolver-289.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (205, 'NF-e est� denegada na base de dados da SEFAZ', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-205-nf-e-est%C3%A1-denegada-na-base-de-dados-da-sefaz-como-resolver-100.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (206, 'Rejei��o: NF-e j� est� inutilizada na Base de dados da SEFAZ', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-206-nf-e-j%C3%A1-est%C3%A1-inutilizada-na-base-de-dados-da-sefaz-como-resolver-101.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (207, 'Rejei��o: CNPJ do emitente inv�lido', 'Verifique o seu CNPJ', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-207-cnpj-do-emitente-inv%C3%A1lido-como-resolver-102.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (208, 'Rejei��o: CNPJ do destinat�rio inv�lido', 'Verifique o CNPJ do destinat�rio', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-208-cnpj-do-destinat%C3%A1rio-inv%C3%A1lido-como-resolver-104.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (209, 'Rejei��o: IE do emitente inv�lida', 'Verifique a sua IE', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-209-ie-do-emitente-inv%C3%A1lida-como-resolver-77.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (210, 'Rejei��o: IE do destinat�rio inv�lida', 'Verifique a IE do destinat�rio', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-210-ie-do-destinat%C3%A1rio-inv%C3%A1lida-como-resolver-79.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (211, 'Rejei��o: IE do substituto inv�lida', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-211-ie-do-substituto-inv%C3%A1lida-como-resolver-45.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (212, 'Rejei��o: Data de emiss�o NF-e posterior a data de recebimento', 'Verifique a data de emiss�o', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-212-data-de-emiss%C3%A3o-posterior-a-data-de-recebimento-como-resolver-105.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (213, 'Rejei��o: CNPJ-Base do Autor difere do CNPJ-Base do Certificado Digital', 'Verificar o CNPJ do certificado', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-213-cnpj-base-do-autor-difere-do-cnpj-base-do-certificado-digital-como-resolver-106.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (214, 'Rejei��o: Tamanho da mensagem excedeu o limite estabelecido', 'Texto muito longo, verifique o texto do documento', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-214-tamanho-da-mensagem-excedeu-o-limite-estabelecido-como-resolver-47.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (215, 'Rejei��o: Falha no schema XML', 'Falha na valida��o do documento', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (216, 'Rejei��o: Chave de Acesso difere da cadastrada', 'Chave diferente da cadastrada, verifique os dados.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (217, 'Rejei��o: NF-e n�o consta na base de dados da SEFAZ', 'Documento n�o consta na base de dados da Sefaz', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-217-nf-e-n%C3%A3o-consta-na-base-de-dados-da-sefaz-como-resolver-113.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (218, 'NF-e j� est� cancelada na base de dados da SEFAZ', 'Documento Cancelado na sefaz', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-218-nf-e-j%C3%A1-est%C3%A1-cancelada-na-base-de-dados-da-sefaz-nrec999999999999999-114.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (219, 'Rejei��o: Circula��o da NF-e verificada', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-219-circula%C3%A7%C3%A3o-da-nf-e-verificada-como-resolver-115.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (220, 'Rejei��o: Prazo de Cancelamento superior ao previsto na Legisla��o', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-220-prazo-de-cancelamento-superior-ao-previsto-na-legisla%C3%A7%C3%A3o-como-resolver-416.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (221, 'Rejei��o: Confirmado o recebimento da NF-e pelo destinat�rio', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-221-confirmado-o-recebimento-da-nf-e-pelo-destinat%C3%A1rio-como-resolver-42.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (222, 'Rejei��o: Protocolo de Autoriza��o de Uso difere do cadastrado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-222-protocolo-de-autoriza%C3%A7%C3%A3o-de-uso-difere-do-cadastrado-como-resolver-290.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (223, 'Rejei��o: CNPJ do transmissor do lote difere do CNPJ do transmissor da consulta', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (224, 'Rejei��o: A faixa inicial � maior que a faixa final', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (225, 'Rejei��o: Falha no Schema XML do lote de NFe', 'Falha no Schema do documento', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (226, 'Rejei��o: C�digo da UF do Emitente diverge da UF autorizadora', 'Verificar com o contador a melhor forma de resolver, c�digo da UF divergente.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (227, 'Rejei��o: Erro na Chave de Acesso - Campo Id ? falta a literal NFe', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (228, 'Rejei��o: Data de Emiss�o muito atrasada', 'Verifique a data de emiss�o', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-228-data-de-emiss%C3%A3o-muito-atrasada-como-resolver-118.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (229, 'Rejei��o: IE do emitente n�o informada', 'Falta informa a IE do emitente', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-229-ie-do-emitente-n%C3%A3o-informada-como-resolver-119.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (230, 'Rejei��o: IE do emitente n�o cadastrada', 'N�o foi encontrado a IE do emitente', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-230-ie-do-emitente-n%C3%A3o-cadastrada-como-resolver-120.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (231, 'Rejei��o: IE do emitente n�o vinculada ao CNPJ', 'Essa IE n�o est� vinculada a este CNPJ', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-231-ie-do-emitente-n%C3%A3o-vinculada-ao-cnpj-cpf-como-resolver-121.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (232, 'Rejei��o: IE do destinat�rio n�o informada', 'Informe a IE do destinat�rio', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-232-ie-do-destinat%C3%A1rio-n%C3%A3o-informada-como-resolver-122.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (233, 'Rejei��o: IE do destinat�rio n�o cadastrada', 'IE do destinatario n�o foi encontrada', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-233-ie-do-destinat%C3%A1rio-n%C3%A3o-cadastrada-como-resolver-292.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (234, 'Rejei��o: IE do destinat�rio n�o vinculada ao CNPJ', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-234-ie-do-destinat%C3%A1rio-n%C3%A3o-vinculada-ao-cnpj-como-resolver-293.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (235, 'Rejei��o: Inscri��o SUFRAMA inv�lida', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (236, 'Rejei��o: Chave de Acesso com d�gito verificador inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (237, 'Rejei��o: CPF do destinat�rio inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-237-cpf-do-destinat%C3%A1rio-inv%C3%A1lido-como-resolver-294.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (238, 'Rejei��o: Cabe�alho - Vers�o do arquivo XML superior a Vers�o vigente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (239, 'Rejei��o: Cabe�alho - Vers�o do arquivo XML n�o suportada', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (240, 'Rejei��o: Cancelamento/Inutiliza��o - Irregularidade Fiscal do Emitente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (241, 'Rejei��o: Um n�mero da faixa j� foi utilizado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-241-um-n%C3%BAmero-da-faixa-j%C3%A1-foi-utilizado-como-resolver-295.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (242, 'Rejei��o: Cabe�alho - Falha no Schema XML', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (243, 'Rejei��o: XML Mal Formado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (244, 'Rejei��o: CNPJ do Certificado Digital difere do CNPJ da Matriz e do CNPJ do Emitente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (245, 'Rejei��o: CNPJ Emitente n�o cadastrado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-245-cnpj-emitente-n%C3%A3o-cadastrado-como-resolver-296.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (246, 'Rejei��o: CNPJ Destinat�rio n�o cadastrado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (247, 'Rejei��o: Sigla da UF do Emitente diverge da UF autorizadora', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (248, 'Rejei��o: UF do Recibo diverge da UF autorizadora', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (249, 'Rejei��o: UF da Chave de Acesso diverge da UF autorizadora', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (250, 'Rejei��o: UF diverge da UF autorizadora', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (251, 'Rejei��o: UF/Munic�pio destinat�rio n�o pertence a SUFRAMA', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (252, 'Rejei��o: Ambiente informado diverge do Ambiente de recebimento', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (253, 'Rejei��o: Digito Verificador da chave de acesso composta inv�lida', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (254, 'Rejei��o: NF-e complementar n�o possui NF referenciada', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-254-nf-e-complementar-n%C3%A3o-possui-nf-referenciada-como-resolver-236.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (255, 'Rejei��o: NF-e complementar possui mais de uma NF referenciada', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-255-nf-e-complementar-possui-mais-de-uma-nf-referenciada-como-resolver-330.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (256, 'Rejei��o: Uma NF-e da faixa j� est� inutilizada na Base de dados da SEFAZ', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-256-uma-nf-e-da-faixa-j%C3%A1-est%C3%A1-inutilizada-na-base-de-dados-da-sefaz-como-resolver-331.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (257, 'Rejei��o: Solicitante n�o habilitado para emiss�o da NF-e', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (258, 'Rejei��o: CNPJ da consulta inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (259, 'Rejei��o: CNPJ da consulta n�o cadastrado como contribuinte na UF', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (260, 'Rejei��o: IE da consulta inv�lida', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (261, 'Rejei��o: IE da consulta n�o cadastrada como contribuinte na UF', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (262, 'Rejei��o: UF n�o fornece consulta por CPF', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (263, 'Rejei��o: CPF da consulta inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (264, 'Rejei��o: CPF da consulta n�o cadastrado como contribuinte na UF', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (265, 'Rejei��o: Sigla da UF da consulta difere da UF do Web Service', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (266, 'Rejei��o: S�rie utilizada n�o permitida no Web Service', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (267, 'Rejei��o: Chave de Acesso referenciada inexistente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-267-chave-de-acesso-referenciada-inexistente-como-resolver-332.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (268, 'Rejei��o: NF Complementar referencia outra NF-e Complementar', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-268-nf-complementar-referencia-uma-outra-nf-e-complementar-como-resolver-333.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (269, 'Rejei��o: CNPJ Emitente da NF Complementar difere do CNPJ da NF Referenciada', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-269-cnpj-emitente-da-nf-complementar-difere-do-cnpj-da-nf-referenciada-como-resolver-334.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (270, 'Rejei��o: C�digo Munic�pio do Fato Gerador de ICMS inexistente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-270-c%C3%B3digo-munic%C3%ADpio-do-fato-gerador-de-icms-inexistente-como-resolver-335.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (271, 'Rejei��o: C�digo Munic�pio do Fato Gerador: difere da UF do emitente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-271-c%C3%B3digo-munic%C3%ADpio-do-fato-gerador-difere-da-uf-do-emitente-como-resolver-337.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (272, 'Rejei��o: C�digo Munic�pio do Emitente inexistente', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-272-c%C3%B3digo-munic%C3%ADpio-do-emitente-inexistente-como-resolver-338.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (273, 'Rejei��o: C�digo Munic�pio do Emitente: difere da UF do emitente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-273-c%C3%B3digo-munic%C3%ADpio-do-emitente-difere-da-uf-do-emitente-como-resolver-339.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (274, 'Rejei��o: C�digo Munic�pio do Destinat�rio inexistente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-274-c%C3%B3digo-munic%C3%ADpio-do-destinat%C3%A1rio-inexistente-como-resolver-340.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (275, 'Rejei��o: C�digo Munic�pio do Destinat�rio: difere da UF do Destinat�rio', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-275-c%C3%B3digo-munic%C3%ADpio-do-destinat%C3%A1rio-difere-da-uf-do-destinat%C3%A1rio-como-resolver-341.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (276, 'Rejei��o: C�digo Munic�pio do Local de Retirada inexistente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-276-c%C3%B3digo-munic%C3%ADpio-do-local-de-retirada-inexistente-como-resolver-342.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (277, 'Rejeicao: C�digo Munic�pio do Local de Retirada: difere da UF do Local de Retirada', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (278, 'Rejeicao: C�digo Munic�pio do Local de Entrega inexistente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-278-c%C3%B3digo-munic%C3%ADpio-do-local-de-entrega-inexistente-como-resolver-346.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (279, 'Rejeicao: C�digo Munic�pio do Local de Entrega: difere da UF do Local de Entrega', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-279-c%C3%B3digo-munic%C3%ADpio-do-local-de-entrega-difere-da-uf-do-local-de-entrega-como-resolver-347.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (280, 'Rejeicao: Certificado Transmissor inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (281, 'Rejeicao: Certificado Transmissor Data Validade', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (282, 'Rejeicao: Certificado Transmissor sem CNPJ', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (283, 'Rejeicao: Certificado Transmissor - erro Cadeia de Certifica��o', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (284, 'Rejeicao: Certificado Transmissor revogado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-284-certificado-transmissor-revogado-como-resolver-57.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (285, 'Rejeicao: Certificado Transmissor difere ICP-Brasil', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (286, 'Rejeicao: Certificado Transmissor erro no acesso a LCR', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (287, 'Rejeicao: C�digo Munic�pio do Fato Gerador de ISSQN inexistente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-287-c%C3%B3digo-munic%C3%ADpio-do-fato-gerador-de-issqn-inexistente-como-resolver-381.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (288, 'Rejeicao: C�digo Munic�pio do Fato Gerador do Transporte inexistente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-288-c%C3%B3digo-munic%C3%ADpio-do-fato-gerador-do-transporte-inexistente-como-resolver-384.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (289, 'Rejeicao: C�digo da UF informada diverge da UF solicitada', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (290, 'Rejeicao: Certificado Assinatura inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (291, 'Rejeicao: Certificado Assinatura Data Validade', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (292, 'Rejeicao: Certificado Assinatura sem CNPJ', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (293, 'Rejeicao: Certificado Assinatura - erro Cadeia de Certifica��o', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (294, 'Rejeicao: Certificado Assinatura revogado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (295, 'Rejeicao: Certificado Assinatura difere ICP-Brasil', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (296, 'Rejeicao: Certificado Assinatura erro no acesso a LCR', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-296-certificado-assinatura-erro-no-acesso-a-lcr-como-resolver-40.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (297, 'Rejeicao: Assinatura difere do calculado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-297-assinatura-difere-do-calculado-como-resolver-266.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (298, 'Rejeicao: Assinatura difere do padr�o do Sistema', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (299, 'Rejeicao: XML da �rea de cabe�alho com codifica��o diferente de UTF-8', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (301, 'Uso Denegado: Irregularidade fiscal do emitente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (302, 'Rejeicao: Irregularidade fiscal do destinat�rio', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-301-uso-denegado-irregularidade-fiscal-do-emitente-como-resolver-27.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (303, 'Uso Denegado: Destinat�rio n�o habilitado a operar na UF', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (304, 'Rejeicao: Pedido de Cancelamento para NF-e com evento da Suframa', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (306, 'Rejeicao: IE do destinatario nao esta ativa na UF', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (315, 'Rejeicao: Data de Emiss�o anterior ao in�cio da autoriza��o de Nota Fiscal na UF', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-315-data-de-emiss%C3%A3o-anterior-ao-in%C3%ADcio-da-autoriza%C3%A7%C3%A3o-de-nota-fiscal-na-uf-como-resolver-353.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (316, 'Rejeicao: Chave de Acesso referenciada com a mesma Chave de Acesso da Nota Fiscal atual�', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-316-nota-fiscal-referenciada-com-a-mesma-chave-de-acesso-da-nota-fiscal-atual-como-resolver-355.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (317, 'Rejeicao: NF modelo 1 referenciada com data de emiss�o inv�lida�', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-317-nf-modelo-1-referenciada-com-data-de-emiss%C3%A3o-inv%C3%A1lida-como-resolver-356.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (318, 'Rejeicao: Contranota de Produtor sem Nota Fiscal referenciada', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (319, 'Rejeicao: Contranota de Produtor n�o pode referenciar somente Nota Fiscal de entrada', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (320, 'Rejeicao: Contranota de Produtor referencia somente NF de outro emitente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (321, 'Rejeicao: NF-e de devolu��o de mercadoria n�o possui documento fiscal referenciado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-321-nf-e-de-devolu%C3%A7%C3%A3o-de-mercadoria-n%C3%A3o-possui-documento-fiscal-referenciado-como-resolver-288.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (322, 'Rejeicao: NF de produtor referenciada com data de emiss�o inv�lida�', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (323, 'Rejeicao: CNPJ autorizado para download inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (324, 'Rejeicao: CNPJ do destinat�rio j� autorizado para download', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-324-cnpj-do-destinat%C3%A1rio-j%C3%A1-autorizado-para-download-como-resolver-235.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (325, 'Rejeicao: CPF autorizado para download inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (326, 'Rejeicao: CPF do destinat�rio j� autorizado para download', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (327, 'Rejeicao: CFOP inv�lido para Nota Fiscal com finalidade de devolu��o de mercadoria', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-327-cfop-inv%C3%A1lido-para-nota-fiscal-com-finalidade-de-devolu%C3%A7%C3%A3o-de-mercadoria-como-resolver-268.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (328, 'Rejeicao: CFOP de devolu��o de mercadoria para NF e que n�o tem finalidade de devolu��o de mercadoria', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-328-cfop-de-devolu%C3%A7%C3%A3o-de-mercadoria-para-nfe-que-n%C3%A3o-tem-finalidade-de-devolu%C3%A7%C3%A3o-de-mercadoria-como-resolver-211.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (329, 'Rejeicao: N�mero da DI /DSI inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (330, 'Rejeicao: Informar o Valor da AFRMM na importa��o por via mar�tima', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (331, 'Rejeicao: Informar o CNPJ do adquirente ou do encomendante nesta forma de importa��o', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (332, 'Rejeicao: CNPJ do adquirente ou do encomendante da importa��o inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (333, 'Rejeicao: Informar a UF do adquirente ou do encomendante nesta forma de importa��o', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (334, 'Rejeicao: N�mero do processo de drawback n�o informado na importa��o', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (335, 'Rejeicao: N�mero do processo de drawback na importa��o inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (336, 'Rejeicao: Informado o grupo de exporta��o no item para CFOP que n�o � de exporta��o', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-336-informado-o-grupo-de-exporta%C3%A7%C3%A3o-no-item-em-opera%C3%A7%C3%A3o-que-n%C3%A3o-%C3%A9-com-exterior-como-resolver-376.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (337, 'Rejeicao: N�o informado o grupo de exporta��o no item', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-337-nfc-e-para-emitente-pessoa-f%C3%ADsica-como-resolver-201.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (338, 'Rejeicao: N�mero do processo de drawback n�o informado na exporta��o', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (339, 'Rejeicao: N�mero do processo de drawback na exporta��o inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (340, 'Rejeicao: N�o informado o grupo de exporta��o indireta no item', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (341, 'Rejeicao: N�mero do registro de exporta��o inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (342, 'Rejeicao: Chave de Acesso informada na Exporta��o Indireta com DV inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (343, 'Rejeicao: Modelo da NF-e informada na Exporta��o Indireta diferente de 55', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (344, 'Rejeicao: Duplicidade de NF-e informada na Exporta��o Indireta (Chave de Acesso informada mais de uma vez)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (345, 'Rejeicao: Chave de Acesso informada na Exporta��o Indireta n�o consta como NF-e referenciada', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (346, 'Rejeicao: Somat�rio das quantidades informadas na Exporta��o Indireta n�o corresponde a quantidade total do item', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (347, 'Rejeicao: Informada IE do substituto tribut�rio em opera��o com Exterior', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-347-informada-ie-do-substituto-tribut%C3%A1rio-em-opera%C3%A7%C3%A3o-com-exterior-como-resolver-372.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (348, 'Rejeicao: NFC-e com grupo RECOPI', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-348-nfc-e-com-grupo-recopi-como-resolver-149.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (349, 'Rejeicao: N�mero RECOPI n�o informado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (350, 'Rejeicao: N�mero RECOPI inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (351, 'Rejeicao: Valor do ICMS da Opera��o no CST=51 difere do produto BC e Al�quota', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-351-valor-do-icms-da-opera%C3%A7%C3%A3o-no-cst-51-difere-do-produto-bc-e-al%C3%ADquota-como-resolver-404.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (352, 'Rejeicao: Valor do ICMS Diferido no CST=51 difere do produto Valor ICMS Opera��o e percentual diferimento', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-352-valor-do-icms-diferido-no-cst-51-difere-do-produto-valor-icms-opera%C3%A7%C3%A3o-e-percentual-diferimento-como-resolver-405.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (353, 'Rejeicao: Valor do ICMS no CST=51 n�o corresponde a diferen�a do ICMS opera��o e ICMS diferido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-353-valor-do-icms-no-cst-51-n%C3%A3o-corresponde-a-diferen%C3%A7a-do-icms-opera%C3%A7%C3%A3o-e-icms-diferido-como-resolver-406.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (354, 'Rejeicao: Informado grupo de devolu��o de tributos para NF-e que n�o tem finalidade de devolu��o de mercadoria', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-354-informado-grupo-de-devolu%c3%a7%c3%a3o-de-tributos-para-nf-e-que-n%c3%a3o-tem-finalidade-de-devolu%c3%a7%c3%a3o-de-mercadoria-como-resolver-814.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (355, 'Rejeicao: Informar o local de sa�da do Pais no caso da exporta��o', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (356, 'Rejeicao: Informar o local de sa�da do Pais somente no caso da exporta��o', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (357, 'Rejeicao: Chave de Acesso do grupo de Exporta��o Indireta inexistente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (358, 'Rejeicao: Chave de Acesso do grupo de Exporta��o Indireta cancelada ou denegada', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (359, 'Rejeicao: NF-e de venda a �rg�o P�blico sem informar a Nota de Empenho', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (360, 'Rejeicao: NF-e com Nota de Empenho inv�lida para a UF.', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (361, 'Rejeicao: NF-e com Nota de Empenho inexistente na UF.', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (362, 'Rejeicao: Venda de combust�vel sem informa��o do Transportador', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-362-venda-de-combust%C3%ADvel-sem-informa%C3%A7%C3%A3o-do-transportador-como-resolver-383.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (363, 'Rejeicao: IE do substituto tribut�rio id�ntica � IE do emitente ou do destinat�rio', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-363-ie-do-substituto-tribut%C3%A1rio-id%C3%AAntica-%C3%A0-ie-do-emitente-ou-do-destinat%C3%A1rio-como-resolver-349.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (364, 'Rejeicao: Total do valor da dedu��o do ISS difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (365, 'Rejeicao: Total de outras reten��es difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (366, 'Rejeicao: Total do desconto incondicionado ISS difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (367, 'Rejeicao: Total do desconto condicionado ISS difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (368, 'Rejeicao: Total de ISS retido difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (369, 'Rejeicao: N�o informado o grupo avulsa na emiss�o pelo Fisco', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (370, 'Rejeicao: Nota Fiscal Avulsa com tipo de emiss�o inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (372, 'Rejeicao: Destinat�rio com identifica��o de estrangeiro com caracteres inv�lidos', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-372-destinat%C3%A1rio-com-identifica%C3%A7%C3%A3o-de-estrangeiro-com-caracteres-inv%C3%A1lidos-como-resolver-358.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (373, 'Rejeicao: Descri��o do primeiro item diferente de NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-373-descri%C3%A7%C3%A3o-do-primeiro-item-diferente-de-nota-fiscal-emitida-em-ambiente-de-homologacao-sem-valor-fiscal-como-resolver-202.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (374, 'Rejeicao: CFOP incompat�vel com o grupo de tributa��o', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-374-cfop-incompat%C3%ADvel-com-o-grupo-de-tributa%C3%A7%C3%A3o-nitem:nnn-como-resolver-203.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (375, 'Rejeicao: NF-e com lan�amento relativo a Cupom Fiscal referencia uma NFC-e', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-375-nf-e-com-lan%C3%A7amento-relativo-a-cupom-fiscal-referencia-uma-nfc-e-como-resolver-373.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (376, 'Rejeicao: Data do Desembara�o Aduaneiro inv�lida', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-376-data-do-desembara%C3%A7o-aduaneiro-inv%C3%A1lida-como-resolver-375.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (377, 'Rejeicao: C�digo de Pa�s do destinat�rio Inexistente�', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-377-c%C3%B3digo-de-pa%C3%ADs-do-destinat%C3%A1rio-inexistente-como-resolver-413.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (378, 'Rejeicao: Grupo de Combust�vel sem a informa��o de Encerrante', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-378-grupo-de-combust%C3%ADvel-sem-a-informa%C3%A7%C3%A3o-de-encerrante-como-resolver-206.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (379, 'Rejeicao: Grupo de Encerrante na NF-e (modelo 55) para CFOP diferente de venda de combust�vel para consumidor final', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-379-grupo-de-encerrante-na-nf-e-modelo-55-para-cfop-diferente-de-venda-de-combust%C3%ADvel-para-consumidor-final-como-resolver-377.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (380, 'Rejeicao: Valor do Encerrante final n�o � superior ao Encerrante inicial', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-380-valor-do-encerrante-final-n%C3%A3o-%C3%A9-superior-ao-encerrante-inicial-como-resolver-378.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (381, 'Rejeicao: Grupo de tributa��o ICMS90, informando dados do ICMS-ST', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-381-grupo-de-tributa%C3%A7%C3%A3o-icms90-informando-dados-do-icms-st-como-resolver-207.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (382, 'Rejeicao: CFOP n�o permitido para o CST informado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-382-cfop-n%C3%A3o-permitido-para-o-cst-informado-como-resolver-208.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (383, 'Rejeicao: Item com CSOSN indevido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-383-item-com-csosn-indevido-como-resolver-213.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (384, 'Rejeicao: CSOSN n�o permitido para a UF', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-384-csosn-n%C3%A3o-permitido-para-a-uf-como-resolver-215.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (385, 'Rejeicao: Grupo de tributa��o ICMSSN900, informando dados do ICMS-ST', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-385-grupo-de-tributa%C3%A7%C3%A3o-icms900-informando-dados-do-icms-st-como-resolver-216.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (386, 'Rejeicao: CFOP n�o permitido para o CSOSN informado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-386-cfop-n%C3%A3o-permitido-para-o-csosn-informado-como-resolver-217.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (387, 'Rejeicao: C�digo de Enquadramento Legal do IPI inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-387-c%C3%B3digo-de-enquadramento-legal-do-ipi-inv%C3%A1lido-como-resolver-359.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (388, 'Rejeicao: C�digo de Situa��o Tribut�ria do IPI incompat�vel com o C�digo de Enquadramento Legaldo IPI', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-388-c%C3%B3digo-de-situa%C3%A7%C3%A3o-tribut%C3%A1ria-do-ipi-incompat%C3%ADvel-com-o-c%C3%B3digo-de-enquadramento-legal-do-ipi-como-resolver-257.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (389, 'Rejeicao: C�digo Munic�pio ISSQN inexistente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-389-c%C3%B3digo-munic%C3%ADpio-issqn-inexistente-como-resolver-382.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (390, 'Rejeicao: Nota Fiscal com grupo de devolu��o de tributos', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-390-nota-fiscal-com-grupo-de-devolu%C3%A7%C3%A3o-de-tributos-como-resolver-218.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (391, 'Rejeicao: N�o informados os dados do cart�o de cr�dito / d�bito nas Formas de Pagamento da Nota Fiscal', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-391-n%C3%A3o-informados-os-dados-do-cart%C3%A3o-de-cr%C3%A9dito-d%C3%A9bito-nas-formas-de-pagamento-da-nota-fiscal-como-resolver-219.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (392, 'Rejeicao: N�o informados os dados da opera��o de pagamento por cart�o de cr�dito / d�bito', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-392-n%C3%A3o-informados-os-dados-da-opera%C3%A7%C3%A3o-de-pagamento-por-cart%C3%A3o-de-cr%C3%A9dito-d%C3%A9bito-como-resolver-220.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (393, 'Rejeicao: NF-e com o grupo de Informa��es Suplementares', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-393-nf-e-com-o-grupo-de-informa%C3%A7%C3%B5es-suplementares-como-resolver-408.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (394, 'Rejeicao: Nota Fiscal sem a informa��o do QR-Code', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-394-nota-fiscal-sem-a-informa%C3%A7%C3%A3o-do-qr-code-como-resolver-221.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (395, 'Rejeicao: Endere�o do site da UF da Consulta via QR Code diverge do previsto', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-395-endere%C3%A7o-do-site-da-uf-da-consulta-via-qr-code-diverge-do-previsto-como-resolver-222.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (396, 'Rejeicao: Par�metro do QR-Code inexistente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-396-par%C3%A2metro-do-qr-code-inexistente-como-resolver-223.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (397, 'Rejeicao: Par�metro do QR-Code divergente da Nota Fiscal', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-397-par%C3%A2metro-do-qr-code-divergente-da-nota-fiscal-como-resolver-224.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (398, 'Rejei��o Par�metro nVersao do QR-Code difere do previsto', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-398-par%C3%A2metro-nversao-do-qr-code-difere-do-previsto-como-resolver-225.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (399, 'Rejeicao: Par�metro de Identifica��o do destinat�rio no QR-Code para Nota Fiscal sem identifica��o do destinat�rio', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-399-par%C3%A2metro-de-identifica%C3%A7%C3%A3o-do-destinat%C3%A1rio-no-qr-code-para-nota-fiscal-sem-identifica%C3%A7%C3%A3o-do-destinat%C3%A1rio-como-resolver-226.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (400, 'Rejeicao: Par�metro do QR-Code n�o est� no formato hexadecimal�', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-400-par%C3%A2metro-do-qr-code-n%C3%A3o-est%C3%A1-no-formato-hexadecimal-como-resolver-227.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (401, 'Rejeicao: CPF do remetente inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (402, 'Rejeicao: XML da �rea de dados com codifica��o diferente de UTF-8', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-402-xml-da-%C3%A1rea-de-dados-com-codifica%C3%A7%C3%A3o-diferente-de-utf-8-como-resolver-254.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (403, 'Rejeicao: O grupo de informa��es da NF-e avulsa � de uso exclusivo do Fisco', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (404, 'Rejeicao: Uso de prefixo de namespace n�o permitido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (405, 'Rejeicao: C�digo do pa�s do emitente: d�gito inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (406, 'Rejeicao: C�digo do pa�s do destinat�rio: d�gito inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (407, 'Rejeicao: O CPF s� pode ser informado no campo emitente para a NF-e avulsa', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-407-o-cpf-s%C3%B3-pode-ser-informado-no-campo-emitente-para-a-nf-e-avulsa-como-resolver-371.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (408, 'Rejeicao: Evento n�o dispon�vel para Autor pessoa f�sica', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (409, 'Rejeicao: Campo cUF inexistente no elemento nfeCabecMsg do SOAP Header', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (410, 'Rejeicao: UF informada no campo cUF n�o � atendida pelo Web Service', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (411, 'Rejeicao: Campo versaoDados inexistente no elemento nfeCabecMsg do SOAP Header', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (416, 'Rejeicao: Falha na descompacta��o da �rea de dados', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (417, 'Rejeicao: Total do ICMS superior ao valor limite estabelecido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (418, 'Rejeicao: Total do ICMS ST superior ao valor limite estabelecido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (420, 'Rejeicao: Cancelamento para NF-e j� cancelada', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (450, 'Rejeicao: Modelo da NF-e diferente de 55', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (451, 'Rejeicao: Processo de emiss�o informado inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (452, 'Rejeicao: Tipo Autorizador do Recibo diverge do �rg�o Autorizador', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (453, 'Rejeicao: Ano de inutiliza��o n�o pode ser superior ao Ano atual', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (454, 'Rejeicao: Ano de inutiliza��o n�o pode ser inferior a 2006', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (455, 'Rejeicao: �rg�o Autor do evento diferente da UF da Chave de Acesso', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (461, 'Rejeicao: Informado percentual de G�s Natural na mistura para produto diferente de GLP', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-461-rejei%c3%a7%c3%a3o-informado-campos-de-percentual-de-glp-e-ou-glgnn-e-ou-glgni-para-produto-diferente-de-glp-como-resolver-755.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (462, 'Rejeicao: C�digo Identificador do CSC no QR-Code n�o cadastrado na SEFAZ', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-462-c%C3%B3digo-identificador-do-csc-no-qr-code-n%C3%A3o-cadastrado-na-sefaz-como-resolver-228.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (463, 'Rejeicao: C�digo Identificador do CSC no QR-Code foi revogado pela empresa', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-463-c%C3%B3digo-identificador-do-csc-no-qr-code-foi-revogado-pela-empresa-como-resolver-229.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (464, 'Rejeicao: C�digo de Hash no QR-Code difere do calculado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-464-c%C3%B3digo-de-hash-no-qr-code-difere-do-calculado-como-resolver-230.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (465, 'Rejeicao: N�mero de Controle da FCI inexistente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (466, 'Rejeicao: Evento com Tipo de Autor incompat�vel', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (467, 'Rejeicao: Dados da NF-e divergentes do EPEC', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (468, 'Rejeicao: NF-e com Tipo Emiss�o = 4, sem EPEC correspondente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-468-nf-e-com-tipo-emiss%C3%A3o-4-sem-epec-correspondente-como-resolver-396.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (471, 'Rejeicao: Informado NCM=00 indevidamente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-471-informado-ncm00-indevidamente-como-resolver-87.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (476, 'Rejeicao: C�digo da UF diverge da UF da primeira NF-e do Lote', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (477, 'Rejeicao: C�digo do �rg�o diverge do �rg�o do primeiro evento do Lote', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (478, 'Rejeicao: Local da entrega n�o informado para faturamento direto de ve�culos novos', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (479, 'Rejeicao: Data de Emiss�o anterior a data de credenciamento ou anterior a Data de Abertura do estabelecimento', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-479-data-de-emiss%C3%A3o-anterior-a-data-de-credenciamento-ou-anterior-a-data-de-abertura-do-estabelecimento-como-resolver-385.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (480, 'Rejeicao: C�digo Munic�pio do Emitente diverge do cadastrado na UF', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-480-c%C3%B3digo-munic%C3%ADpio-do-emitente-diverge-do-cadastrado-na-uf-como-resolver-386.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (481, 'Rejeicao: C�digo Regime Tribut�rio do emitente diverge do cadastro na SEFAZ', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-481-c%C3%B3digo-regime-tribut%C3%A1rio-do-emitente-diverge-do-cadastro-na-sefaz-como-resolver-351.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (482, 'Rejeicao: C�digo do Munic�pio do Destinat�rio diverge do cadastrado na UF', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-482-c%C3%B3digo-do-munic%C3%ADpio-do-destinat%C3%A1rio-diverge-do-cadastrado-na-uf-como-resolver-350.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (483, 'Rejeicao: Valor do desconto maior que valor do produto', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-483-valor-do-desconto-maior-que-valor-do-produto-como-resolver-374.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (484, 'Rejeicao: Chave de Acesso com tipo de emiss�o diferente de 4 (posi��o 35 da Chave de Acesso)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (485, 'Rejeicao: Duplicidade de numera��o do EPEC (Modelo, CNPJ, S�rie e N�mero)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (486, 'Rejeicao: N�o informado o Grupo de Autoriza��o para UF que exige a identifica��o do Escrit�rio de Contabilidade na Nota Fiscal', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-486-n%C3%A3o-informado-o-grupo-de-autoriza%C3%A7%C3%A3o-para-uf-que-exige-a-identifica%C3%A7%C3%A3o-do-escrit%C3%B3rio-de-contabilidade-na-nota-fiscal-como-resolver-287.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (487, 'Rejeicao: Escrit�rio de Contabilidade n�o cadastrado na SEFAZ', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-487-escrit%C3%B3rio-de-contabilidade-n%C3%A3o-cadastrado-na-sefaz-como-resolver-403.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (488, 'Rejeicao: Vendas do Emitente incompat�veis com o Porte da Empresa', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-488-vendas-do-emitente-incompat%C3%ADveis-com-o-porte-da-empresa-como-resolver-388.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (489, 'Rejeicao: CNPJ informado inv�lido (DV ou zeros)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (490, 'Rejeicao: CPF informado inv�lido (DV ou zeros)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (491, 'Rejeicao: O tpEvento informado inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (492, 'Rejeicao: O verEvento informado inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (493, 'Rejeicao: Evento n�o atende o Schema XML espec�fico', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (494, 'Rejeicao: Chave de Acesso inexistente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (496, 'Rejeicao: N�o informado o tipo de integra��o no pagamento com cart�o de cr�dito / d�bito', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (501, 'Rejeicao: Pedido de Cancelamento intempestivo (NF-e autorizada a mais de 7 dias)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (502, 'Rejeicao: Erro na Chave de Acesso - Campo Id n�o corresponde � concatena��o dos campos correspondentes', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (503, 'Rejeicao: S�rie utilizada fora da faixa permitida no SCAN (900-999)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (504, 'Rejeicao: Data de Entrada/Sa�da posterior ao permitido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (505, 'Rejeicao: Data de Entrada/Sa�da anterior ao permitido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (506, 'Rejeicao: Data de Sa�da menor que a Data de Emiss�o', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-506-data-de-sa%C3%ADda-menor-que-a-data-de-emiss%C3%A3o-como-resolver-234.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (507, 'Rejeicao: O CNPJ do destinat�rio/remetente n�o deve ser informado em opera��o com o exterior', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (508, 'Rejeicao: CST incompat�vel na opera��o com N�o Contribuinte', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-508-cst-incompat%C3%ADvel-na-opera%C3%A7%C3%A3o-com-n%C3%A3o-contribuinte-como-resolver-310.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (509, 'Rejeicao: Informado c�digo de munic�pio diferente de ?9999999? para opera��o com o exterior', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-509-informado-c%C3%B3digo-de-munic%C3%ADpio-diferente-de-%E2%80%9C9999999%E2%80%9D-para-opera%C3%A7%C3%A3o-com-o-exterior-como-resolver-311.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (510, 'Rejeicao: Opera��o com Exterior e C�digo Pa�s destinat�rio � 1058 (Brasil) ou n�o informado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (511, 'Rejeicao: N�o � de Opera��o com Exterior e C�digo Pa�s destinat�rio difere de 1058 (Brasil)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-511-n%C3%A3o-%C3%A9-de-opera%C3%A7%C3%A3o-com-exterior-e-c%C3%B3digo-pa%C3%ADs-destinat%C3%A1rio-difere-de-1058-brasil-como-resolver-344.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (512, 'Rejeicao: CNPJ do Local de Retirada inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (513, 'Rejeicao: C�digo Munic�pio do Local de Retirada deve ser 9999999 para UF retirada = EX', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (514, 'Rejeicao: CNPJ do Local de Entrega inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (515, 'Rejeicao: C�digo Munic�pio do Local de Entrega deve ser 9999999 para UF entrega = EX', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (516, 'Rejeicao: Falha no schema XML ? inexiste a tag raiz esperada para a mensagem', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (517, 'Rejeicao: Falha no schema XML ? inexiste atributo versao na tag raiz da mensagem', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (518, 'Rejeicao: CFOP de entrada para NF-e de sa�da', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-518-cfop-de-entrada-para-nf-e-de-sa%C3%ADda-como-resolver-307.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (519, 'Rejeicao: CFOP de sa�da para NF-e de entrada', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-519-cfop-de-sa%C3%ADda-para-nf-e-de-entrada-como-resolver-308.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (520, 'Rejeicao: CFOP de Opera��o com Exterior e UF destinat�rio difere de EX', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-520-cfop-de-opera%C3%A7%C3%A3o-com-exterior-e-uf-destinat%C3%A1rio-difere-de-%E2%80%9Cex%E2%80%9D-como-resolver-309.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (521, 'Rejeicao: Opera��o Interna e UF do emitente difere da UF do destinat�rio/remetente contribuinte do ICMS', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-521-opera%C3%A7%C3%A3o-interna-e-uf-do-emitente-difere-da-uf-do-destinat%C3%A1rio-remetente-contribuinte-do-icms-como-resolver-52.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (522, 'Rejeicao: Chave de Acesso referenciada com UF inv�lida', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (523, 'Rejeicao: CFOP n�o � de Opera��o Estadual e UF emitente igual a UF destinat�rio.', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (524, 'Rejeicao: Chave de Acesso referenciada com Ano-M�s inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (525, 'Rejeicao: CFOP de Importa��o e n�o informado dados da DI', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-525-cfop-de-importa%C3%A7%C3%A3o-e-n%C3%A3o-informado-dados-da-di-como-resolver-441.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (526, 'Rejeicao: Ano-M�s da Chave de Acesso com atraso superior a 6 meses em rela��o ao Ano-M�s atual', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-526-ano-m%C3%AAs-da-chave-de-acesso-com-atraso-superior-a-6-meses-em-rela%C3%A7%C3%A3o-ao-ano-m%C3%AAs-atual-como-resolver-354.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (527, 'Rejeicao: Opera��o de Exporta��o com informa��o de ICMS incompat�vel', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-527-opera%C3%A7%C3%A3o-de-exporta%C3%A7%C3%A3o-com-informa%C3%A7%C3%A3o-de-icms-incompat%C3%ADvel-como-resolver-239.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (528, 'Rejeicao: Valor do ICMS difere do produto BC e Al�quota', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-528-valor-do-icms-difere-do-produto-bc-e-al%C3%ADquota-como-resolver-299.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (529, 'Rejeicao: CST incompat�vel na opera��o com Contribuinte Isento de Inscri��o Estadual', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-529-cst-incompat%C3%ADvel-na-opera%C3%A7%C3%A3o-com-contribuinte-isento-de-inscri%C3%A7%C3%A3o-estadual-como-resolver-324.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (530, 'Rejeicao: Opera��o com tributa��o de ISSQN sem informar a Inscri��o Municipal', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (531, 'Rejeicao: Total da BC ICMS difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-531-total-da-bc-icms-difere-do-somat%C3%B3rio-dos-itens-como-resolver-49.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (532, 'Rejeicao: Total do ICMS difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-532-total-do-icms-difere-do-somat%C3%B3rio-dos-itens-como-resolver-61.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (533, 'Rejeicao: Total da BC ICMS-ST difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-533-total-da-bc-icms-st-difere-do-somat%C3%B3rio-dos-itens-como-resolver-306.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (534, 'Rejeicao: Total do ICMS-ST difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-534-total-do-icms-st-difere-do-somat%C3%B3rio-dos-itens-como-resolver-305.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (535, 'Rejeicao: Total do Frete difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-535-total-do-frete-difere-do-somat%C3%B3rio-dos-itens-como-resolver-304.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (536, 'Rejeicao: Total do Seguro difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-536-total-do-seguro-difere-do-somat%C3%B3rio-dos-itens-como-resolver-303.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (537, 'Rejeicao: Total do Desconto difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-537-total-do-desconto-difere-do-somat%C3%B3rio-dos-itens-como-resolver-302.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (538, 'Rejeicao: Total do IPI difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-538-total-do-ipi-difere-do-somat%C3%B3rio-dos-itens-como-resolver-301.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (539, 'Duplicidade de NF-e com diferen�a na Chave de Acesso', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-539-duplicidade-de-nf-e-com-diferen%C3%A7a-na-chave-de-acesso-como-resolver-39.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (540, 'Rejeicao: CPF do Local de Retirada inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (541, 'Rejeicao: CPF do Local de Entrega inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (542, 'Rejeicao: CNPJ do Transportador inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (543, 'Rejeicao: CPF do Transportador inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (544, 'Rejeicao: IE do Transportador inv�lida', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (545, 'Rejeicao: Falha no schema XML ? vers�o informada na versaoDados do SOAPHeader diverge da vers�o da mensagem', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (546, 'Rejeicao: Erro na Chave de Acesso ? Campo Id ? falta a literal NFe', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (547, 'Rejeicao: D�gito Verificador da Chave de Acesso da NF-e Referenciada inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (548, 'Rejeicao: CNPJ da NF referenciada inv�lido.', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (549, 'Rejeicao: CNPJ da NF referenciada de produtor inv�lido.', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (550, 'Rejeicao: CPF da NF referenciada de produtor inv�lido.', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (551, 'Rejeicao: IE da NF referenciada de produtor inv�lido.', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (552, 'Rejeicao: D�gito Verificador da Chave de Acesso do CT-e Referenciado inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (553, 'Rejeicao: Tipo autorizador do recibo diverge do �rg�o Autorizador.', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (554, 'Rejeicao: S�rie difere da faixa 0-899', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (555, 'Rejeicao: Tipo autorizador do protocolo diverge do �rg�o Autorizador.', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (556, 'Rejeicao: Justificativa de entrada em conting�ncia n�o deve ser informada para tipo de emiss�o normal.', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (557, 'Rejeicao: A Justificativa de entrada em conting�ncia deve ser informada.', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (558, 'Rejeicao: Data de entrada em conting�ncia posterior a data de recebimento.', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (559, 'Rejeicao: UF do Transportador n�o informada', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (560, 'Rejeicao: CNPJ base do emitente difere do CNPJ base da primeira NF-e do lote recebido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (561, 'Rejeicao: M�s de Emiss�o informado na Chave de Acesso difere do M�s de Emiss�o da NF-e', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (562, 'Rejeicao: C�digo Num�rico informado na Chave de Acesso difere do C�digo Num�rico da NF-e', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (563, 'Rejeicao: J� existe pedido de Inutiliza��o com a mesma faixa de inutiliza��o', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-563-j%C3%A1-existe-pedido-de-inutiliza%C3%A7%C3%A3o-com-a-mesma-faixa-de-inutiliza%C3%A7%C3%A3o-como-resolver-194.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (564, 'Rejeicao: Total do Produto / Servi�o difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-564-total-do-produto-servi%C3%A7o-difere-do-somat%C3%B3rio-dos-itens-como-resolver-277.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (565, 'Rejeicao: Falha no schema XML ? inexiste a tag raiz esperada para o lote de NF-e', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (567, 'Rejeicao: Falha no schema XML ? vers�o informada na versaoDados do SOAPHeader diverge da vers�o do lote de NF-e', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (568, 'Rejeicao: Falha no schema XML ? inexiste atributo versao na tag raiz do lote de NF-e', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (569, 'Rejeicao: Data de entrada em conting�ncia muito atrasada', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-569-data-de-entrada-em-conting%C3%AAncia-muito-atrasada-como-resolver-111.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (570, 'Rejeicao: Tipo de Emiss�o 3, 6 ou 7 s� � v�lido nas conting�ncias SCAN/SVC', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (571, 'Rejeicao: O tpEmis informado diferente de 3 para conting�ncia SCAN', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (572, 'Rejeicao: Erro Atributo ID do evento n�o corresponde a concatena��o dos campos (?ID? + tpEvento + chNFe + nSeqEvento)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (573, 'Rejeicao: Duplicidade de Evento', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-573-duplicidade-de-evento-como-resolver-444.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (574, 'Rejeicao: O autor do evento diverge do emissor da NF-e', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (575, 'Rejeicao: O autor do evento diverge do destinat�rio da NF-e', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (576, 'Rejeicao: O autor do evento n�o � um �rg�o autorizado a gerar o evento', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (577, 'Rejeicao: A data do evento n�o pode ser menor que a data de emiss�o da NF-e', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (578, 'Rejeicao: A data do evento n�o pode ser maior que a data do processamento', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-578-a-data-do-evento-n%C3%A3o-pode-ser-maior-que-a-data-do-processamento-como-resolver-10.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (579, 'Rejeicao: A data do evento n�o pode ser menor que a data de autoriza��o para NF-e n�o emitida em conting�ncia', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (580, 'Rejeicao: O evento exige uma NF-e autorizada', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (587, 'Rejeicao: Usar somente o namespace padr�o da NF-e', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (588, 'Rejeicao: N�o � permitida a presen�a de caracteres de edi��o no in�cio/fim da mensagem ou entre as tags da mensagem', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (589, 'Rejeicao: N�mero do NSU informado superior ao maior NSU da base de dados da SEFAZ', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (590, 'Rejeicao: Informado CST para emissor do Simples Nacional (CRT=1)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (591, 'Rejeicao: Informado CSOSN para emissor que n�o � do Simples Nacional (CRT diferente de 1)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (592, 'Rejeicao: A NF-e deve ter pelo menos um item de produto sujeito ao ICMS', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (593, 'Rejeicao: CNPJ-Base consultado difere do CNPJ-Base do Certificado Digital', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (594, 'Rejeicao: O n�mero de sequencia do evento informado � maior que o permitido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (595, 'Rejeicao: Obrigat�ria a informa��o da justificativa do evento.', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (596, 'Rejeicao: Evento apresentado fora do prazo: [prazo vigente]', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (597, 'Rejeicao: CFOP de Importa��o e n�o informado dados de IPI', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-597-cfop-de-importa%C3%A7%C3%A3o-e-n%C3%A3o-informado-dados-de-ipi-como-resolver-442.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (598, 'Rejeicao: NF-e emitida em ambiente de homologa��o com Raz�o Social do destinat�rio diferente de NF-E EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (599, 'Rejeicao: CFOP de Importa��o e n�o informado dados de II', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-599-cfop-de-importa%C3%A7%C3%A3o-e-n%C3%A3o-informado-dados-de-ii-como-resolver-443.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (600, 'Rejeicao: CSOSN incompat�vel na opera��o com N�o Contribuinte', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-600-csosn-incompat%C3%ADvel-na-opera%C3%A7%C3%A3o-com-n%C3%A3o-contribuinte-como-resolver-325.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (601, 'Rejeicao: Total do II difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-601-total-do-ii-difere-do-somat%C3%B3rio-dos-itens-como-resolver-313.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (602, 'Rejeicao: Total do PIS difere do somat�rio dos itens sujeitos ao ICMS', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-602-total-do-pis-difere-do-somat%C3%B3rio-dos-itens-sujeitos-ao-icms-como-resolver-314.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (603, 'Rejeicao: Total do COFINS difere do somat�rio dos itens sujeitos ao ICMS', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-603-total-da-cofins-difere-do-somat%C3%B3rio-dos-itens-sujeitos-ao-icms-como-resolver-315.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (604, 'Rejeicao: Total do vOutro difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-604-total-do-voutro-difere-do-somat%C3%B3rio-dos-itens-como-resolver-316.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (605, 'Rejeicao: Total do vISS difere do somat�rio do vProd dos itens sujeitos ao ISSQN', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-605-total-do-vserv-difere-do-somat%C3%B3rio-do-vprod-dos-itens-sujeitos-ao-issqn-como-resolver-317.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (606, 'Rejeicao: Total do vBC do ISS difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-606-total-do-vbc-do-iss-difere-do-somat%C3%B3rio-dos-itens-como-resolver-318.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (607, 'Rejeicao: Total do ISS difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-607-total-do-iss-difere-do-somat%C3%B3rio-dos-itens-como-resolver-320.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (608, 'Rejeicao: Total do PIS difere do somat�rio dos itens sujeitos ao ISSQN', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-608-total-do-pis-difere-do-somat%C3%B3rio-dos-itens-sujeitos-ao-issqn-como-resolver-321.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (609, 'Rejeicao: Total do COFINS difere do somat�rio dos itens sujeitos ao ISSQN', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-609-total-da-cofins-difere-do-somat%C3%B3rio-dos-itens-sujeitos-ao-issqn-como-resolver-322.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (610, 'Rejeicao: Total da NF difere do somat�rio dos Valores comp�e o valor Total da NF.', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-610-total-da-nf-difere-do-somat%C3%B3rio-dos-valores-comp%C3%B5e-o-valor-total-da-nf-como-resolver-297.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (611, 'Rejeicao: cEAN inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-611-cean-inv%C3%A1lido-como-resolver-258.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (612, 'Rejeicao: cEANTrib inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-612-gtin-da-unidade-tribut%c3%a1vel-ceantrib-inv%c3%a1lido-como-resolver-489.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (613, 'Rejeicao: Chave de Acesso difere da existente em BD', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-613-chave-de-acesso-difere-da-existente-em-bd-como-resolver-370.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (614, 'Rejeicao: Chave de Acesso inv�lida (C�digo UF inv�lido)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (615, 'Rejeicao: Chave de Acesso inv�lida (Ano menor que 06 ou Ano maior que Ano corrente)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (616, 'Rejeicao: Chave de Acesso inv�lida (M�s menor que 1 ou M�s maior que 12)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (617, 'Rejeicao: Chave de Acesso inv�lida (CNPJ zerado ou d�gito inv�lido)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (618, 'Rejeicao: Chave de Acesso inv�lida (modelo diferente de 55 e 65)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (619, 'Rejeicao: Chave de Acesso inv�lida (n�mero NF = 0)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (620, 'Rejeicao: Chave de Acesso difere da existente em BD', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (621, 'Rejeicao: CPF Emitente n�o cadastrado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (622, 'Rejeicao: IE emitente n�o vinculada ao CPF', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (623, 'Rejeicao: CPF Destinat�rio n�o cadastrado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (624, 'Rejeicao: IE Destinat�rio n�o vinculada ao CPF', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (625, 'Rejeicao: Inscri��o SUFRAMA deve ser informada na venda com isen��o para ZFM', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (626, 'Rejeicao: CFOP de opera��o isenta para ZFM diferente do previsto', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (627, 'Rejeicao: O valor do ICMS desonerado deve ser informado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (628, 'Rejeicao: Total da NF superior ao valor limite estabelecido pela SEFAZ', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (629, 'Rejeicao: Valor do Produto difere do produto Valor Unit�rio de Comercializa��o e Quantidade Comercial', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-629-valor-do-produto-difere-do-produto-valor-unit%C3%A1rio-de-comercializa%C3%A7%C3%A3o-e-quantidade-comercial-como-resolver-44.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (630, 'Rejeicao: Valor do Produto difere do produto Valor Unit�rio de Tributa��o e Quantidade Tribut�vel', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-630-valor-do-produto-difere-do-produto-valor-unit%C3%A1rio-de-tributa%C3%A7%C3%A3o-e-quantidade-tribut%C3%A1vel-como-resolver-312.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (631, 'Rejeicao: CNPJ-Base do Destinat�rio difere do CNPJ-Base do Certificado Digital', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (632, 'Rejeicao: Solicita��o fora de prazo, a NF-e n�o est� mais dispon�vel para download', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (633, 'Rejeicao: NF-e indispon�vel para download devido a aus�ncia de Manifesta��o do Destinat�rio', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (634, 'Rejeicao: Destinat�rio da NF-e n�o tem o mesmo CNPJ raiz do solicitante do download', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (635, 'Rejeicao: NF-e com mesmo n�mero e s�rie j� transmitida e aguardando processamento', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-635-nf-e-com-mesmo-n%C3%BAmero-e-s%C3%A9rie-j%C3%A1-transmitida-e-aguardando-processamento-como-resolver-123.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (650, '"Rejei��o: Evento de ""Ci�ncia da Emiss�o"" para NF-e Cancelada ou Denegada"', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (651, '"Rejei��o: Evento de ""Desconhecimento da Opera��o"" para NF-e Cancelada ou Denegada"', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (653, 'Rejeicao: NF-e Cancelada, arquivo indispon�vel para download', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (654, 'Rejeicao: NF-e Denegada, arquivo indispon�vel para download', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (655, 'Rejeicao: Evento de Ci�ncia da Emiss�o informado ap�s a manifesta��o final do destinat�rio', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (656, 'Rejeicao: Consumo Indevido', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-656-consumo-indevido-como-resolver-4.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (657, 'Rejeicao: C�digo do �rg�o diverge do �rg�o autorizador', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (658, 'Rejeicao: UF do destinat�rio da Chave de Acesso diverge da UF autorizadora', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (660, 'Rejeicao: CFOP de Combust�vel e n�o informado grupo de combust�vel', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-660-cfop-de-combust%C3%ADvel-e-n%C3%A3o-informado-grupo-de-combust%C3%ADvel-nitem:nnn-como-resolver-274.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (661, 'Rejeicao: NF-e j� existente para o n�mero do EPEC informado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (662, 'Rejeicao: Numera��o do EPEC est� inutilizada na Base de Dados da SEFAZ', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (663, 'Rejeicao: Al�quota do ICMS com valor superior a 4 por cento na opera��o de sa�da interestadual com produtos importados', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-663-al%C3%ADquota-do-icms-com-valor-superior-a-4-por-cento-na-opera%C3%A7%C3%A3o-de-sa%C3%ADda-interestadual-com-produtos-importados-como-resolver-107.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (678, 'Rejeicao: NF referenciada com UF diferente da NF-e complementar', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (679, 'Rejeicao: Modelo da NF-e referenciada diferente de 55/65', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-679-modelo-de-df-e-referenciado-inv%C3%A1lido-como-resolver-348.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (680, 'Rejeicao: Chave de Acesso referenciada em duplicidade na NF-e�', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-680-chave-de-acesso-referenciada-em-duplicidade-na-nf-e-como-resolver-414.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (681, 'Rejeicao: Duplicidade de NF Modelo 1 referenciada (CNPJ, Modelo, S�rie e N�mero)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (682, 'Rejeicao: Duplicidade de NF de Produtor referenciada (IE, Modelo, S�rie e N�mero)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (683, 'Rejeicao: Chave de Acesso referenciada com N�mero inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-683-chave-de-acesso-referenciada-com-n%C3%BAmero-inv%C3%A1lido-como-resolver-415.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (684, 'Rejeicao: Duplicidade de Cupom Fiscal referenciado (Modelo, N�mero de Ordem e COO)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (685, 'Rejeicao: Total do Valor Aproximado dos Tributos difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (686, 'Rejeicao: NF Complementar referencia uma NF-e cancelada', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (687, 'Rejeicao: NF Complementar referencia uma NF-e denegada', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (688, 'Rejeicao: NF referenciada de Produtor com IE inexistente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (689, 'Rejeicao: NF referenciada de Produtor com IE n�o vinculada ao CNPJ/CPF informado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (690, 'Rejeicao: Pedido de Cancelamento para NF-e com CT-e', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-690-pedido-de-cancelamento-para-nf-e-com-ct-e-ou-mdf-e-como-resolver-63.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (691, 'Rejeicao: Chave de Acesso da NF-e diverge da Chave de Acesso do EPEC', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (693, 'Rejeicao: Al�quota de ICMS superior a definida para a opera��o interestadual', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-693-al%C3%ADquota-de-icms-superior-a-definida-para-a-opera%C3%A7%C3%A3o-interestadual-como-resolver-326.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (694, 'Rejeicao: N�o informado o grupo de ICMS para a UF de destino', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-694-n%C3%A3o-informado-o-grupo-de-icms-para-a-uf-de-destino-como-resolver-361.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (695, 'Rejeicao: Informado indevidamente o grupo de ICMS para a UF de destino', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-695-informado-indevidamente-o-grupo-de-icms-para-a-uf-de-destino-como-resolver-362.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (696, 'Rejeicao: Opera��o com n�o contribuinte deve indicar opera��o com consumidor final', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-696-opera%C3%A7%C3%A3o-com-n%C3%A3o-contribuinte-deve-indicar-opera%C3%A7%C3%A3o-com-consumidor-final-como-resolver-402.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (697, 'Rejeicao: Al�quota interestadual do ICMS com origem diferente do previsto', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-697-al%C3%ADquota-interestadual-do-icms-com-origem-diferente-do-previsto-como-resolver-363.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (698, 'Rejeicao: Al�quota interestadual do ICMS incompat�vel com as UF envolvidas na opera��o', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-698-al%C3%ADquota-interestadual-do-icms-incompat%C3%ADvel-com-as-uf-envolvidas-na-opera%C3%A7%C3%A3o-como-resolver-364.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (699, 'Rejeicao: Percentual do ICMS Interestadual para a UF de destino difere do previsto para o ano da Data de Emiss�o', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-699-percentual-do-icms-interestadual-para-a-uf-de-destino-difere-do-previsto-para-o-ano-da-data-de-emiss%C3%A3o-como-resolver-365.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (701, 'Rejeicao: N�o informado Nota Fiscal referenciada (Lan�amento relativo a Cupom Fiscal)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-701-n%C3%A3o-informado-nota-fiscal-referenciada-como-resolver-275.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (702, 'Rejeicao: NFC-e n�o � aceita pela UF do Emitente', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-702-nfc-e-n%C3%A3o-%C3%A9-aceita-pela-uf-do-emitente-como-resolver-150.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (703, 'Rejeicao: Data-Hora de Emiss�o posterior ao hor�rio de recebimento', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-703-data-hora-de-emiss%C3%A3o-posterior-ao-hor%C3%A1rio-de-recebimento-como-resolver-151.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (704, 'Rejeicao: NFC-e com Data-Hora de emiss�o atrasada', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-704-nfc-e-com-data-hora-de-emiss%C3%A3o-atrasada-como-resolver-124.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (705, 'Rejeicao: NFC-e com data de entrada/sa�da', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-705-nfc-e-com-data-de-entradasa%C3%ADda-como-resolver-125.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (706, 'Rejeicao: NFC-e para opera��o de entrada', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-706-nfc-e-para-opera%C3%A7%C3%A3o-de-entrada-como-resolver-126.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (707, 'Rejeicao: NFC-e para opera��o interestadual ou com o exterior', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-707-nfc-e-para-opera%C3%A7%C3%A3o-interestadual-ou-com-o-exterior-como-resolver-127.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (708, 'Rejeicao: NFC-e n�o pode referenciar documento fiscal', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-708-nfc-e-n%C3%A3o-pode-referenciar-documento-fiscal-como-resolver-128.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (709, 'Rejeicao: NFC-e com formato de DANFE inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-709-nfc-e-com-formato-de-danfe-inv%C3%A1lido-como-resolver-129.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (710, 'Rejeicao: NF-e com formato de DANFE inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-710-nf-e-com-formato-de-danfe-inv%C3%A1lido-como-resolver-130.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (711, 'Rejeicao: NF-e com conting�ncia off-line', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-711-nf-e-com-conting%C3%AAncia-off-line-como-resolver-131.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (712, 'Rejeicao: NFC-e com conting�ncia off-line para a UF', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-712-nfc-e-com-conting%C3%AAncia-off-line-para-a-uf-como-resolver-132.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (713, 'Rejeicao: Tipo de Emiss�o diferente de 6 ou 7 para conting�ncia da SVC acessada', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-713-tipo-de-emiss%C3%A3o-diferente-de-6-ou-7-para-conting%C3%AAncia-da-svc-acessada-como-resolver-133.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (714, 'Rejeicao: NFC-e com op��o de conting�ncia inv�lida (tpEmis=2, 4 (a crit�rio da UF) ou 5)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-714-nfc-e-com-op%C3%A7%C3%A3o-de-conting%C3%AAncia-inv%C3%A1lida-tpemis-2-4-a-crit%C3%A9rio-da-uf-ou-5-como-resolver-134.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (715, 'Rejeicao: NFC-e com finalidade inv�lida', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-715-nfc-e-com-finalidade-inv%C3%A1lida-como-resolver-135.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (716, 'Rejeicao: NFC-e em opera��o n�o destinada a consumidor final', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-716-nfc-e-em-opera%C3%A7%C3%A3o-n%C3%A3o-destinada-a-consumidor-final-como-resolver-136.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (717, 'Rejeicao: NFC-e em opera��o n�o presencial', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-717-nfc-e-em-opera%C3%A7%C3%A3o-n%C3%A3o-presencial-como-resolver-137.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (718, 'Rejeicao: NFC-e n�o deve informar IE de Substituto Tribut�rio', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-718-nfc-e-n%C3%A3o-deve-informar-ie-de-substituto-tribut%C3%A1rio-como-resolver-138.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (719, 'Rejeicao: NF-e sem a identifica��o do destinat�rio', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (720, 'Rejeicao: Na opera��o com Exterior deve ser informada tag idEstrangeiro', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-720-na-opera%C3%A7%C3%A3o-com-exterior-deve-ser-informada-tag-idestrangeiro-como-resolver-139.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (721, 'Rejeicao: Informado idEstrangeiro e Opera��o n�o � com consumidor final.', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-721-informado-idestrangeiro-e-opera%C3%A7%C3%A3o-n%C3%A3o-%C3%A9-com-consumidor-final-como-resolver-399.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (722, 'Rejeicao: CFOP de Transporte Inexistente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-722-cfop-de-transporte-inexistente-como-resolver-409.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (723, 'Rejeicao: Opera��o interna com idEstrangeiro informado deve ser para consumidor final', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (724, 'Rejeicao: NF-e sem o nome do destinat�rio', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-724-nf-e-sem-o-nome-do-destinat%C3%A1rio-como-resolver-142.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (725, 'Rejeicao: NFC-e com CFOP inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-725-nfc-e-com-cfop-inv%C3%A1lido-como-resolver-143.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (726, 'Rejeicao: NF-e sem a informa��o de endere�o do destinat�rio', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-726-nf-e-sem-a-informa%C3%A7%C3%A3o-de-endere%C3%A7o-do-destinat%C3%A1rio-como-resolver-144.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (727, 'Rejeicao: Opera��o com Exterior e UF diferente de EX', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (728, 'Rejeicao: NF-e sem informa��o da IE do destinat�rio', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-728-nf-e-sem-informa%C3%A7%C3%A3o-da-ie-do-destinat%C3%A1rio-como-resolver-145.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (729, 'Rejeicao: NFC-e com informa��o da IE do destinat�rio', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-729-nfc-e-com-informa%C3%A7%C3%A3o-da-ie-do-destinat%C3%A1rio-como-resolver-146.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (730, 'Rejeicao: NFC-e com Inscri��o Suframa', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-730-nfc-e-com-inscri%C3%A7%C3%A3o-suframa-como-resolver-147.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (731, 'Rejeicao: CFOP de opera��o com Exterior e idDest <> 3', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-731-cfop-de-opera%C3%A7%C3%A3o-com-exterior-e-iddest-diferente-de-3-como-resolver-148.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (732, 'Rejeicao: CFOP de opera��o interestadual e idDest <> 2', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-732-cfop-de-opera%C3%A7%C3%A3o-interestadual-e-iddest-diferente-de-2-como-resolver-397.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (733, 'Rejeicao: CFOP de opera��o interna e idDest <> 1', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-733-cfop-de-opera%C3%A7%C3%A3o-interna-e-iddest-diferente-de-1-como-resolver-398.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (734, 'Rejeicao: NFC-e com Unidade de Comercializa��o inv�lida', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-734-nfc-e-com-unidade-de-comercializa%C3%A7%C3%A3o-inv%C3%A1lida-como-resolver-152.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (735, 'Rejeicao: NFC-e com Unidade de Tributa��o inv�lida', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-735-nfc-e-com-unidade-de-tributa%C3%A7%C3%A3o-inv%C3%A1lida-como-resolver-153.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (736, 'Rejeicao: NFC-e com grupo de Ve�culos novos', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-736-nfc-e-com-grupo-de-ve%C3%ADculos-novos-como-resolver-154.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (737, 'Rejeicao: Pagamento com cart�o de cr�dito em sistema de automa��o n�o integrado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-737-pagamento-com-cart%C3%A3o-de-cr%C3%A9dito-em-sistema-de-automa%C3%A7%C3%A3o-n%C3%A3o-integrado-como-resolver-448.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (738, 'Rejeicao: NFC-e com grupo de Armamentos', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-738-nfc-e-com-grupo-de-armamentos-como-resolver-156.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (739, 'Rejeicao: C�digo de Pa�s do ISSQN Inexistente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-739-c%C3%B3digo-de-pa%C3%ADs-do-issqn-inexistente-como-resolver-157.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (740, 'Rejeicao: Item com Repasse de ICMS retido por Substituto Tribut�rio', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-740-item-com-repasse-de-icms-retido-por-substituto-tribut%C3%A1rio-como-resolver-158.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (741, 'Rejeicao: NFC-e com Partilha de ICMS entre UF', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-741-nfc-e-com-partilha-de-icms-entre-uf-como-resolver-159.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (742, 'Rejeicao: NFC-e com grupo do IPI', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-742-nfc-e-com-grupo-do-ipi-como-resolver-160.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (743, 'Rejeicao: NFC-e com grupo do II', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-743-nfc-e-com-grupo-do-ii-como-resolver-161.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (745, 'Rejeicao: NF-e sem grupo do PIS', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (746, 'Rejeicao: NFC-e com grupo do PIS-ST', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-746-nfc-e-com-grupo-do-pis-st-como-resolver-162.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (748, 'Rejeicao: NF-e sem grupo da COFINS', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (749, 'Rejeicao: NFC-e com grupo da COFINS-ST', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (750, 'Rejeicao: NFC-e com valor total superior ao permitido para destinat�rio n�o identificado (C�digo)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (751, 'Rejeicao: NFC-e com valor total superior ao permitido para destinat�rio n�o identificado (Nome)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (752, 'Rejeicao: NFC-e com valor total superior ao permitido para destinat�rio n�o identificado(Endere�o)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (753, 'Rejeicao: NFC-e com Frete', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (754, 'Rejeicao: NFC-e com dados do Transportador', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (755, 'Rejeicao: NFC-e com dados de Reten��o do ICMS no Transporte', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (756, 'Rejeicao: NFC-e com dados do ve�culo de Transporte', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (757, 'Rejeicao: NFC-e com dados de Reboque do ve�culo de Transporte', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (758, 'Rejeicao: NFC-e com dados do Vag�o de Transporte', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (759, 'Rejeicao: NFC-e com dados da Balsa de Transporte', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (760, 'Rejeicao: NFC-e com dados de cobran�a (Fatura, Duplicata)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-760-nfc-e-com-dados-de-cobran%C3%A7a-fatura-duplicata-como-resolver-177.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (761, 'Rejeicao: C�digo de Produto ANP inexistente', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-761-c%C3%B3digo-de-produto-anp-inexistente-como-resolver-360.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (762, 'Rejeicao: NFC-e com dados de compras (Empenho, Pedido, Contrato)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-762-nfc-e-com-dados-de-compras-empenho-pedido-contrato-como-resolver-178.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (763, 'Rejeicao: NFC-e com dados de aquisi��o de Cana', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-763-nfc-e-com-dados-de-aquisi%C3%A7%C3%A3o-de-cana-como-resolver-179.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (764, 'Rejeicao: Solicitada resposta s�ncrona para Lote com mais de uma NF-e (indSinc=1)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (765, 'Rejeicao: Lote s� poder� conter NF-e ou NFC-e', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (766, 'Rejeicao: Item com CST indevido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-766-rejei%C3%A7%C3%A3o-item-com-cst-indevido-como-resolver-180.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (767, 'Rejeicao: NFC-e com somat�rio dos pagamentos diferente do total da Nota Fiscal', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-767-nfc-e-com-somat%C3%B3rio-dos-pagamentos-diferente-do-total-da-nota-fiscal-como-resolver-181.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (768, 'Rejeicao: NF-e n�o deve possuir o grupo de Formas de Pagamento', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (769, 'Rejeicao: NFC-e deve possuir o grupo de Formas de Pagamento', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-769-nfc-e-deve-possuir-o-grupo-de-formas-de-pagamento-como-resolver-182.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (770, 'Rejeicao: CFOP Inexistente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-770-cfop-inexistente-como-resolver-412.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (771, 'Rejeicao: Informado idEstrangeiro em opera��o interestadual', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-771-informado-idestrangeiro-em-opera%C3%A7%C3%A3o-interestadual-como-resolver-411.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (772, 'Rejeicao: Opera��o Interestadual e UF de destino igual � UF de origem', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-772-opera%C3%A7%C3%A3o-interestadual-e-uf-de-destino-igual-%C3%A0-uf-de-origem-como-resolver-475.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (773, 'Rejeicao: Opera��o Interna e UF de destino difere da UF do emitente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-773-opera%C3%A7%C3%A3o-interna-e-uf-de-destino-difere-da-uf-de-origem-como-resolver-476.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (774, 'Rejei��o: NFC-e com indicador de item n�o participante do total', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-774-nfc-e-com-indicador-de-item-n%C3%A3o-participante-do-total-como-resolver-184.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (775, 'Rejei��o: Modelo da NFC-e diferente de 65', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-775-modelo-da-nfc-e-diferente-de-65-como-resolver-185.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (776, 'Rejei��o: Solicitada resposta s�ncrona para UF que n�o disponibiliza este atendimento (indSinc=1)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (777, 'Rejei��o: Obrigat�ria a informa��o do NCM completo', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-777-obrigat%C3%B3ria-a-informa%C3%A7%C3%A3o-do-ncm-completo-como-resolver-84.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (778, 'Rejei��o: Informado NCM inexistente', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-778-informado-ncm-inexistente-como-resolver-86.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (779, 'Rejei��o: NFC-e com NCM incompat�vel', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-779-nfc-e-com-ncm-incompat%C3%ADvel-como-resolver-186.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (780, 'Rejei��o: Total da NFC-e superior ao valor limite estabelecido pela SEFAZ', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-780-total-da-nfc-e-superior-ao-valor-limite-estabelecido-pela-sefaz-como-resolver-187.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (781, 'Rejei��o: Emissor n�o habilitado para emiss�o da NFC-e', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-781-emissor-n%C3%A3o-habilitado-para-emiss%C3%A3o-da-nfc-e-como-resolver-188.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (782, 'Rejei��o: NFC-e n�o � autorizada pelo SCAN', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-782-nfc-e-n%C3%A3o-%C3%A9-autorizada-pelo-scan-como-resolver-189.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (783, 'Rejei��o: NFC-e n�o � autorizada pela SVC', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-783-nfc-e-n%C3%A3o-%C3%A9-autorizada-pela-svc-como-resolver-190.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (784, 'Rejei��o: NFC-e n�o permite o evento de Carta de Corre��o', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-784-nfc-e-n%C3%A3o-permite-o-evento-de-carta-de-corre%C3%A7%C3%A3o-como-resolver-191.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (785, 'Rejei��o: NFC-e com entrega a domic�lio n�o permitida pela UF', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-785-nfc-e-com-entrega-a-domic%C3%ADlio-n%C3%A3o-permitida-pela-uf-como-resolver-192.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (786, 'Rejei��o: NFC-e de entrega a domic�lio sem dados do Transportador', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-786-nfc-e-de-entrega-a-domic%C3%ADlio-sem-dados-do-transportador-como-resolver-169.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (787, 'Rejei��o: NFC-e de entrega a domic�lio sem a identifica��o do destinat�rio', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-787-nfc-e-de-entrega-a-domic%C3%ADlio-sem-a-identifica%C3%A7%C3%A3o-do-destinat%C3%A1rio-como-resolver-170.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (788, 'Rejei��o: NFC-e de entrega a domic�lio sem o endere�o do destinat�rio', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-788-nfc-e-de-entrega-a-domic%C3%ADlio-sem-o-endere%C3%A7o-do-destinat%C3%A1rio-como-resolver-171.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (789, 'Rejei��o: NFC-e para destinat�rio contribuinte de ICMS', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-789-nfc-e-para-destinat%C3%A1rio-contribuinte-de-icms-como-resolver-193.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (790, 'Rejei��o: Opera��o com Exterior para destinat�rio Contribuinte de ICMS', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (791, 'Rejei��o: NF-e com indica��o de destinat�rio isento de IE, com a informa��o da IE do destinat�rio', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-791-nf-e-com-indica%C3%A7%C3%A3o-de-destinat%C3%A1rio-isento-de-ie-com-a-informa%C3%A7%C3%A3o-da-ie-do-destinat%C3%A1rio-como-resolver-237.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (792, 'Rejei��o: Informada a IE do destinat�rio para opera��o com destinat�rio no Exterior', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (793, 'Rejei��o: Valor do ICMS relativo ao Fundo de Combate � Pobreza na UF de destino difere do calculado', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-793-valor-do-icms-relativo-ao-fundo-de-combate-%C3%A0-pobreza-na-uf-de-destino-difere-do-calculado-como-resolver-366.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (794, 'Rejei��o: NF-e com indicativo de NFC-e com entrega a domic�lio', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (795, 'Rejei��o: Total do ICMS desonerado difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/erros-e-rejei%C3%A7%C3%B5es-na-emiss%C3%A3o-de-nfe-e-nfce-mapeados-no-oobj-dfe-453.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (798, 'Rejei��o: Valor total do ICMS relativo Fundo de Combate � Pobreza (FCP) da UF de destino difere do somat�rio do valor dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-798-valor-total-do-icms-relativo-fundo-de-combate-%C3%A0-pobreza-fcp-da-uf-de-destino-difere-do-somat%C3%B3rio-do-valor-dos-itens-como-resolver-368.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (799, 'Rejei��o: Valor total do ICMS Interestadual da UF de destino difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-799-valor-total-do-icms-interestadual-da-uf-de-destino-difere-do-somat%C3%B3rio-dos-itens-como-resolver-367.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (800, 'Rejei��o: Valor total do ICMS Interestadual da UF do remetente difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-800-valor-total-do-icms-interestadual-da-uf-do-remetente-difere-do-somat%C3%B3rio-dos-itens-como-resolver-369.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (805, 'Rejei��o: A SEFAZ do destinat�rio n�o permite Contribuinte Isento de Inscri��o Estadual em opera��es interestaduais.', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-805-a-sefaz-do-destinat%C3%A1rio-n%C3%A3o-permite-contribuinte-isento-de-inscri%C3%A7%C3%A3o-estadual-em-opera%C3%A7%C3%B5es-interestaduais-como-resolver-323.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (806, 'Rejei��o: Opera��o com ICMS-ST sem informa��o do CEST.', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-806-opera%C3%A7%C3%A3o-com-icms-st-sem-informa%C3%A7%C3%A3o-do-cest-como-resolver-328.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (807, 'Rejei��o: NFC-e com grupo de ICMS para a UF do destinat�rio', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-807-nfc-e-com-grupo-de-icms-para-a-uf-do-destinat%C3%A1rio-como-resolver-329.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (812, 'Rejei��o: Regime Tribut�rio SN, com excesso de sublimite n�o � permitido para Emitentes desta UF', 'Verificar com o contador a melhor forma de resolver.', 'http://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-812-regime-tribut%C3%A1rio-sn-com-excesso-de-sublimite-n%C3%A3o-%C3%A9-permitido-para-emitentes-desta-uf-como-resolver-447.html');
COMMIT WORK;
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (813, 'Rejei��o: QR-Code com sequ�ncia de escape para o e-comercial. Usar CDATA', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-813-qr-code-com-sequ%C3%AAncia-de-escape-para-o-e-comercial-usar-cdata-como-resolver-450.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (814, 'Rejei��o: Nota Fiscal com grupo de com�rcio exterior', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-814-nota-fiscal-com-grupo-de-com%C3%A9rcio-exterior-como-resolver-449.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (872, 'Rejei��o: A SEFAZ do destinat�rio n�o permite Contribuinte Isento de Inscri��o Estadual em opera��es internas', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-872-a-sefaz-do-destinat%c3%a1rio-n%c3%a3o-permite-contribuinte-isento-de-inscri%c3%a7%c3%a3o-estadual-em-opera%c3%a7%c3%b5es-internas-como-resolver-477.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (999, 'Rejei��o: Erro n�o catalogado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%C3%A7%C3%A3o-999-erro-n%C3%A3o-catalogado-como-resolver-256.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (851, 'Rejei��o 851: Soma do valor das parcelas difere do Valor L�quido da Fatura', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-851-soma-do-valor-das-parcelas-difere-do-valor-l%c3%adquido-da-fatura-como-resolver-764.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (852, 'Rejei��o 852: N�mero da parcela inv�lido ou n�o informado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-852-n%c3%bamero-da-parcela-inv%c3%a1lido-ou-n%c3%a3o-informado-como-resolver-766.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (854, 'Rejei��o 854: Unidade Tribut�vel (tag: uTrib) incompat�vel com produto informado', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-854-unidade-tribut%c3%a1vel-tag-utrib-incompat%c3%advel-com-produto-informado-como-resolver-758.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (855, 'Rejei��o 855: Somat�rio percentuais de GLP derivado do petr�leo, GLGNn e GLGNi diferente de 100', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-855-somat%c3%b3rio-percentuais-de-glp-derivado-do-petr%c3%b3leo-glgnn-e-glgni-diferente-de-100-como-resolver-756.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (856, 'Rejei��o 856: Campo valor de partida n�o preenchido para produto GLP', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-856-campo-valor-de-partida-n%c3%a3o-preenchido-para-produto-glp-como-resolver-757.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (857, 'Rejei��o 857: Informado Duplicata Mercantil como Forma de Pagamento', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-857-informado-duplicata-mercantil-como-forma-de-pagamento-como-resolver-791.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (858, 'Rejei��o 858: Grupo de Tributa��o informado indevidamente [nItem: nnn]', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-858-grupo-de-tributa%c3%a7%c3%a3o-informado-indevidamente-nitem-nnn-como-resolver-796.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (859, 'Rejei��o 859: Total do FCP retido anteriormente por Substitui��o Tribut�ria difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-859-total-do-fcp-retido-anteriormente-por-substitui%c3%a7%c3%a3o-tribut%c3%a1ria-difere-do-somat%c3%b3rio-dos-itens-como-resolver-760.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (860, 'Rejei��o 860: Valor do FCP informado difere de base de c�lculo*al�quota [nItem: nnn]', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-860-valor-do-fcp-informado-difere-de-base-de-c%c3%a1lculo%2aal%c3%adquota-nitem-nnn-como-resolver-776.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (861, 'Rejei��o 861: Total do FCP difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-861-total-do-fcp-difere-do-somat%c3%b3rio-dos-itens-como-resolver-761.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (862, 'Rejei��o 862: Total do FCP ST difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-862-total-do-fcp-st-difere-do-somat%c3%b3rio-dos-itens-como-resolver-762.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (863, 'Rejei��o 863: Total do IPI devolvido difere do somat�rio dos itens', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-863-total-do-ipi-devolvido-difere-do-somat%c3%b3rio-dos-itens-como-resolver-808.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (864, 'Rejei��o 864: NF-e com indicativo de Opera��o presencial, fora do estabelecimento e n�o informada NF-e referenciada', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-864-nf-e-com-indicativo-de-opera%c3%a7%c3%a3o-presencial-fora-do-estabelecimento-e-n%c3%a3o-informada-nf-e-referenciada-como-resolver-797.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (865, 'Rejei��o 865: Total dos pagamentos menor que o total da nota', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-865-total-dos-pagamentos-menor-que-o-total-da-nota-como-resolver-809.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (866, 'Rejei��o 866: Aus�ncia de troco quando o valor dos pagamentos informados for maior que o total da nota', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-866-aus%c3%aancia-de-troco-quando-o-valor-dos-pagamentos-informados-for-maior-que-o-total-da-nota-como-resolver-810.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (868, 'Rejei��o 868: Grupos Ve�culo Transporte e Reboque n�o devem ser informados', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-868-grupos-ve%c3%adculo-transporte-e-reboque-n%c3%a3o-devem-ser-informados-como-resolver-798.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (869, 'Rejei��o 869: Valor do troco incorreto', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-869-valor-do-troco-incorreto-como-resolver-763.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (870, 'Rejei��o 870: Data de validade incompat�vel com data de fabrica��o [nItem:nnn]', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-870-data-de-validade-incompat%c3%advel-com-data-de-fabrica%c3%a7%c3%a3o-nitemnnn-como-resolver-792.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (871, 'Rejei��o 871: O campo Meio de Pagamento deve ser preenchido com a op��o Sem Pagamento', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-871-o-campo-meio-de-pagamento-deve-ser-preenchido-com-a-op%c3%a7%c3%a3o-sem-pagamento-como-resolver-777.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (873, 'Rejei��o 873: Opera��o com medicamentos e n�o informado os campos de rastreabilidade [nItem:nnn] ', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-873-opera%c3%a7%c3%a3o-com-medicamentos-e-n%c3%a3o-informado-os-campos-de-rastreabilidade-nitemnnn-como-resolver-790.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (874, 'Rejei��o 874: Percentual de FCP inv�lido [nItem: nnn]', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-874-percentual-de-fcp-inv%c3%a1lido-nitem-nnn-como-resolver-783.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (815, 'Rejei��o: Valor do ICMS Interestadual para UF de Destino difere do calculado [nItem:999] (Valor Informado: XXX, Valor Calculado:XXX) ', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-815-valor-do-icms-interestadual-para-uf-de-destino-difere-do-calculado-nitem999-valor-informado-xxx-valor-calculadoxxx-como-resolver-478.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (816, 'Rejei��o 816: Valor do ICMS Interestadual para UF do Remetente difere do calculado [nItem:999] (Valor Informado: XXX, Valor Calculado:XXX)', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-816-valor-do-icms-interestadual-para-uf-do-remetente-difere-do-calculado-nitem999-valor-informado-xxx-valor-calculadoxxx-como-resolver-479.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (817, 'Rejei��o 817: Unidade Tribut�vel incompat�vel com o NCM informado na opera��o com Com�rcio Exterior [nItem:nnn]', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-817-unidade-tribut%c3%a1vel-incompat%c3%advel-com-o-ncm-informado-na-opera%c3%a7%c3%a3o-com-com%c3%a9rcio-exterior-nitemnnn-como-resolver-484.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (850, 'Rejei��o 850: Data de vencimento da parcela n�o informada ou menor que a Data de vencimento da parcela anterior', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-850-data-de-vencimento-da-parcela-n%c3%a3o-informada-ou-menor-que-a-data-de-vencimento-da-parcela-anterior-como-resolver-773.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (875, 'Rejei��o 875: Percentual de FCPST inv�lido [nItem: nnn]', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-875-percentual-de-fcpst-inv%c3%a1lido-nitem-nnn-como-resolver-784.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (876, 'Rejei��o 876: Opera��o interestadual para Consumidor Final e valor do FCP informado em campo diferente de vFCPUFDest (id:NA13) [nItem:nnn]', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-876-opera%c3%a7%c3%a3o-interestadual-para-consumidor-final-e-valor-do-fcp-informado-em-campo-diferente-de-vfcpufdest-idna13-nitemnnn-como-resolver-785.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (877, 'Rejei��o 877: Data de fabrica��o maior que a data de processamento [nItem:nnn]', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-877-data-de-fabrica%c3%a7%c3%a3o-maior-que-a-data-de-processamento-nitemnnn-como-resolver-787.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (878, 'Rejei��o 878: Endere�o do site da UF da Consulta por chave de acesso diverge do previsto', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-878-endere%c3%a7o-do-site-da-uf-da-consulta-por-chave-de-acesso-diverge-do-previsto-como-resolver-811.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (879, 'Rejei��o 879: Informado item �Produzido em Escala N�O Relevante� e n�o informado CNPJ do Fabricante [nItem:nnn]', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-879-informado-item-%e2%80%9cproduzido-em-escala-n%c3%83o-relevante%e2%80%9d-e-n%c3%a3o-informado-cnpj-do-fabricante-nitemnnn-como-resolver-794.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (880, 'Rejei��o 880: Percentual de FCP igual a zero', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-880-percentual-de-fcp-igual-a-zero-nitem-nnn-como-resolver-778.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (881, 'Rejei��o 881: Percentual de FCP ST igual a zero', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-881-percentual-de-fcp-st-igual-a-zero-nitem-nnn-como-resolver-779.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (882, 'Rejei��o 882: GTIN (cEAN) com prefixo inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-882-gtin-cean-com-prefixo-inv%c3%a1lido-nitem999-como-resolver-767.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (883, 'Rejei��o 883: GTIN (cEAN) sem informa��o', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-883-gtin-cean-sem-informa%c3%a7%c3%a3o-nitem999-como-resolver-771.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (884, 'Rejei��o 884: GTIN da unidade tribut�vel (cEANTrib) com prefixo inv�lido', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-884-gtin-da-unidade-tribut%c3%a1vel-ceantrib-com-prefixo-inv%c3%a1lido-nitem999-como-resolver-768.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (885, 'Rejei��o 885: GTIN informado, mas n�o informado o GTIN da unidade tribut�vel', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-885-gtin-informado-mas-n%c3%a3o-informado-o-gtin-da-unidade-tribut%c3%a1vel-nitem999-como-resolver-769.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (886, 'Rejei��o 886: GTIN da unidade tribut�vel informado, mas n�o informado o GTIN', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-886-gtin-da-unidade-tribut%c3%a1vel-informado-mas-n%c3%a3o-informado-o-gtin-nitem999-como-resolver-770.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (887, 'Rejei��o 887: Informado GTIN de agrupamento de produtos homog�neos (GTIN-14) no GTIN da unidade tribut�vel', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-887-informado-gtin-de-agrupamento-de-produtos-homog%c3%aaneos-gtin-14-no-gtin-da-unidade-tribut%c3%a1vel-nitem999-como-resolver-765.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (888, 'Rejei��o 888: GTIN da unidade tribut�vel (cEANTrib) sem informa��o', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-888-gtin-da-unidade-tribut%c3%a1vel-ceantrib-sem-informa%c3%a7%c3%a3o-nitem999-como-resolver-772.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (889, 'Rejei��o 889: Obrigat�ria a informa��o do GTIN para o produto', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-889-obrigat%c3%b3ria-a-informa%c3%a7%c3%a3o-do-gtin-para-o-produto-nitem999-como-resolver-799.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (899, 'Rejei��o 899: Informado incorretamente o campo meio de pagamento', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-899-informado-incorretamente-o-campo-meio-de-pagamento-como-resolver-786.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (900, 'Rejei��o 900: Data de vencimento da parcela n�o informada ou menor que Data de Emiss�o', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-900-data-de-vencimento-da-parcela-n%c3%a3o-informada-ou-menor-que-data-de-emiss%c3%a3o-como-resolver-781.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (901, 'Rejei��o 901: Valor do Desconto da Fatura maior que o Valor Original da Fatura ', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-901-valor-do-desconto-da-fatura-maior-que-o-valor-original-da-fatura-como-resolver-774.html');
UPDATE OR INSERT INTO ENS_ERROS_NFE (COD_ERRO_NFE, DESCRICAO, COMO_RESOLVER, LINK_SOLUCAO)
                   VALUES (902, 'Rejei��o 902: Valor Liquido da Fatura difere do Valor Original menos o Valor do Desconto ', 'Verificar com o contador a melhor forma de resolver.', 'https://www.oobj.com.br/bc/article/rejei%c3%a7%c3%a3o-902-valor-liquido-da-fatura-difere-do-valor-original-menos-o-valor-do-desconto-como-resolver-782.html');

COMMIT WORK;
